R0dis=zeros(17,1);
R1dis=zeros(17,1);
C1dis=zeros(17,1);
i_dis=10.233;%�ŵ����
B=0;
for sheet=1:3
NUM0=xlsread('T-1007fang',sheet);
C=NUM0;
B=combine(B,C);
end%�����ļ���3��sheet��Ϊһ������
m=find(B(:,8)==4 & B(:,9)==1);% ��÷ŵ�ʱ��ͬSOC�µ�ŷķ����
for i=2:18%��90%��10%	
    R0dis(i-1)= abs(B(m(i)-1,11)+(-1*B(m(i),11)))/i_dis;
    for z=1:100
        V_dis(z)=B(m(i)+z-1,11);% ȡ100���ŵ��ѹ����
    end
    t=1:100;
    myfunc=inline('beta(1)-beta(2)*(1-exp(-beta(3)*t))','beta','t'); %������Ϻ���
    beta=lsqcurvefit(myfunc,[3.51 0.08991 0.1306],t,V_dis); %���ֵ����ϲ���
    R1dis(i-1)=beta(2)/i_dis;
    C1dis(i-1)=1/(beta(3)*R1dis(i-1));
end

% % x=0.9609:-0.0499:0.1625;
% % xx=0.9609:-0.7984/13057:0.1625;
% % y=R1dis';
% % yy=interp1(x,y,xx,'Linear');
% % 
% % % x=0.9609:-0.0499:0.1625;
% % % xx=0.9609:-0.7984/13057:0.1625;
% % % y1=R2dis';
% % % yy1=interp1(x,y1,xx,'Linear');
% % 
% % x=0.9609:-0.0499:0.1625;
% % xx=0.9609:-0.7984/13057:0.1625;
% % y2=C1dis';
% % yy2=interp1(x,y2,xx,'Linear');
% % 
% % % x=0.9609:-0.0499:0.1625;
% % % xx=0.9609:-0.7984/13057:0.1625;
% % % y3=C2dis';
% % % yy3=interp1(x,y3,xx,'Linear');
% % 
% % x=0.9609:-0.0499:0.1625;
% % xx=0.9609:-0.7984/13057:0.1625;
% % y4=R0dis';
% yy4=interp1(x,y4,xx,'Linear');


F=xlsread('T-2001��Ԫ��ز���ģ��DSTѭ������'); 
l=find(F(:,8)== 100&F(:,9)== 1);%��ÿ��SOC�·ŵ��ʼλ��
for i=1:(l(287)-l(27)+1)%��90%��10%
    U_DST(i)= F(l(3)+i-1,11);%����ѹ���ݷŵ�������
    I_DST(i)= F(l(3)+i-1,10);%���������ݷŵ�������SOC=S(1,:);
end
    N=length(U_DST);
for m=1:N
    sum1(1)=0;
    sum1(m+1)=sum1(m)-I_DST(m);
end
for m=2:(N+1)

sum1(m-1)=sum1(m);
SOC1(m-1)=0.96-sum1(m-1)./(33*3600);

x=0.9599:(0.3115-0.9599)/16:0.3115;
xx=SOC1;
y=R1dis';
yy=interp1(x,y,xx);

% x=0.9599:(0.3115-0.9599)/16:0.3115;
% xx=SOC1;
% y1=R2dis';
% yy1=interp1(x,y1,xx);

x=0.9599:(0.3115-0.9599)/16:0.3115;
xx=SOC1;
y2=C1dis';
yy2=interp1(x,y2,xx);

% x=0.9599:(0.3115-0.9599)/16:0.3115;
% xx=SOC1;
% y3=C2dis';
% yy3=interp1(x,y3,xx);

x=0.9599:(0.3115-0.9599)/16:0.3115;
xx=SOC1;
y4=R0dis';
yy4=interp1(x,y4,xx);
end
for m=2:(N+1);
% U(m-1)=11.0106*(SOC1(m-1)^5)-33.48*(SOC1(m-1)^4)+38.7861*(SOC1(m-1)^3)-20.5421*(SOC1(m-1)^2)+5.1771*SOC1(m-1)+3.2529;
Udis1(m-1)=4.2+yy4(m-1)*I_DST(m-1)+yy(m-1)*I_DST(m-1)*(1-exp(-(1/(yy(m-1)*yy2(m-1)))));
end
% %    lineW=1.5;
% % subplot(2,1,1);
% %  plot(i,Udis(i),'r','LineWidth',lineW);
% %  hold on;
% %  plot(i,U_DST(i),'b','LineWidth',lineW);
% %  grid on;
% % ylabel('U(v)','fontsize',20,'fontname','Times New Roman')
% % xlabel('Time (s)','fontsize',20,'fontname','Times New Roman')
% % subplot(2,1,2);
% % plot(i,U_DST(i)-Udis(i),'LineWidth',lineW);
% % grid on
% % ylabel('Error','fontsize',20,'fontname','Times New Roman')
% % xlabel('Time (s)','fontsize',20,'fontname','Times New Roman')
% % % error=V_dis(k)-Udis(k);
% % % errormean=mean(error);
% end
