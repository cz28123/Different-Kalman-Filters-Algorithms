B=0;
for sheet=1:3
A=xlsread('T-1007fang',sheet);
C=A;
B=combine(B,C);
end


x=B(:,1);
y=B(:,10);

grid on;
plot(x,y,'b');
ylabel('Current(A)','fontsize',20,'fontname','Times New Roman')
xlabel('time(s)','fontsize',20,'fontname','Times New Roman')
