R0dis=zeros(17,1);
R1dis=zeros(17,1);
C1dis=zeros(17,1);
R2dis=zeros(17,1);
C2dis=zeros(17,1);
i_dis=10.233;% �ŵ����
error=0;
B=0;
for sheet=1:3
NUM0=xlsread('T-1007fang',sheet);
C=NUM0;
B=combine(B,C);
end%�����ļ���3��sheet��Ϊһ������
m=find(B(:,8)==4 & B(:,9)==1);% ��÷ŵ�ʱ��ͬSOC�µ�ŷķ����
for i=2:18%��90%��10%	
    R0dis(i-1)= abs(B(m(i)-1,11)+(-1*B(m(i),11)))/i_dis;
    for z=1:100
        V_dis(z)=B(m(i)+z-1,11);% ȡ100���ŵ��ѹ����
    end
    t=1:100;
    myfunc=inline('beta(1)-beta(2)*(1-exp(-beta(3)*t))-beta(4)*(1-exp(-beta(5)*t))','beta','t'); %������Ϻ���
    beta=lsqcurvefit(myfunc,[3.51 0.08991 0.1306 0.1771 0.01127],t,V_dis); %���ֵ����ϲ���
    R1dis(i-1)=beta(2)/i_dis;
    C1dis(i-1)=1/(beta(3)*R1dis(i-1));
    R2dis(i-1)=beta(4)/i_dis;
    C2dis(i-1)=1/(beta(5)*R2dis(i-1));

% R0mean=mean(R0dis);% ��ȡƽ��ֵ
% R1mean=mean(R1dis);%
% C1mean=mean(C1dis);%
% C2mean=mean(C2dis);%
%  R2mean=mean(R2dis);%
Udis=beta(1)-beta(2)*(1-exp(-beta(3)*t))-beta(4)*(1-exp(-beta(5)*t));
lineW=1.5;
k=1:100;
subplot(2,1,1);
 plot(k,Udis(k),'r','LineWidth',lineW);
 hold on;
 plot(k,V_dis(k),'b','LineWidth',lineW);
 grid on;
ylabel('U(v)','fontsize',20,'fontname','Times New Roman')
xlabel('Time (s)','fontsize',20,'fontname','Times New Roman')
subplot(2,1,2);
plot(k,V_dis(k)-Udis(k),'LineWidth',lineW);
grid on
ylabel('Error','fontsize',20,'fontname','Times New Roman')
xlabel('Time (s)','fontsize',20,'fontname','Times New Roman')
error=V_dis(k)-Udis(k);
errormean=mean(error);
end
